
string1 = "fnbotuxvedqgihkpjrywcmslazkjaiqlubmcfstzrwnhegvdoxpy"
string2 = f'{string1[24]+string1[-1]+string1[4]+string1[8]+string1[22]+string1[24]+string1[17]+string1[0]} {string1[12]+string1[-18]+string1[-12]+string1[24]} {string1[-4]+string1[0]+string1[12]+string1[-5]}'
print(string2)