N = int(input("masukan angka:"))

print("ouput",N,"adalah")
for i in range(1,N+1,2):
    print(i)