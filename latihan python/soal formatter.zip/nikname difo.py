_string ="abjiytwrsgnmzcqxfodhpkeuvlegdmzkoyjsutqvefphrxwlanbi"
name = f"{_string[18]+_string[-1]+_string[-11]+_string[17]}"
print(name)