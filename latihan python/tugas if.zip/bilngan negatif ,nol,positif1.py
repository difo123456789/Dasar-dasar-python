nilai = 5

if (nilai > 0 ):
  print("positif")
if (nilai == 0 ):
  print("nol")
if (nilai < 0):
  print("negatif")