jumlah_lembar = int(input("jumlah lembar fotokopi:"))

if(jumlah_lembar < 100):
    tota_biaya = jumlah_lembar * 150
elif(jumlah_lembar >= 100 and jumlah_lembar <= 200):
    total_biaya = jumlah_lembar * 100
else:
    total_biaya = jumlah_lembar * 80

print("total biaya fokopi adalah rp.",total_biaya)