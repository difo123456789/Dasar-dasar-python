umur = 56

if(umur <= 5):
    print("kriterianya balita")
if( 5< umur <= 13):
    print("kriterianya anak-anak")
elif( 13< umur <= 25):
    print("kriterianya remaja")
elif( 25< umur <= 35):
    print("kriterianya dewasa")
elif( 35< umur <= 55):
    print("kriterianya orang tua")
elif( umur >55):
    print("kriterianya lansia")
    
